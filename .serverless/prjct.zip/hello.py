def handler(event, context):
    print('hellow everyone!')
    return {'message': 'Hi'}
